var sel;
sel = $(document);
sel.ready(inicializarEventos);

function inicializarEventos () {
	var sel;
	sel = $(".primera_tabla a");
	sel.mouseover(inColor1);

	var sel;
	sel = $(".primera_tabla a");
	sel.mouseout(offColorA);

	var sel;
	sel = $(".cajita");
	sel.mouseover(inColor2);

	var sel;
	sel = $(".cajita");
	sel.mouseout(offColorA);
}

function inColor1(){
	$(this).css("background-color", "rgb(255, 243, 175)");
}

function inColor2(){
	$(this).css("background-color", "rgb(255, 243, 175)");
}

function offColorA(){
	$(this).css("background-color", "#C590F4");
}